# Pombo - Plano de Migração para Arquitetura Dual-Stream

## 📍 Contexto do Problema

### Situação Atual (Problemática)
Cada canal Pombo usa **1 stream Streamr com 3 partições**:
- Partição 0: Mensagens de texto, reações, imagens (COM storage)
- Partição 1: Metadados/Controlo (presence, typing) - **problema: também é stored**
- Partição 2: Media (chunks de ficheiros grandes) - **problema: também é stored**

### O Problema de Privacidade
**O storage no Streamr é PER-STREAM, não per-partition.**

Quando `stream.addToStorageNode()` é chamado:
- TODAS as partições são armazenadas
- Metadados de presença (quem está online, quando) ficam persistidos eternamente
- Indicadores de "typing" são armazenados
- Isto é uma **falha grave de privacidade** - metadados comportamentais não devem ser persistidos

### Confirmação da Pesquisa
A documentação do Streamr SDK confirma:
1. `addToStorageNode(storageNodeAddress)` - sem parâmetro de partição
2. `resend()` funciona por partição, mas só se a partição estiver armazenada
3. Não existe API para armazenar partições seletivamente

---

## 🎯 Solução Proposta

### Nova Arquitetura: 2 Streams por Canal

```
CANAL "Nome do Canal"
├── Stream 1: Messages (COM STORAGE)
│   ├── Partição 0: Mensagens de texto, reações, imagens, announcements de vídeo
│   └── (apenas 1 partição necessária)
│
└── Stream 2: Ephemeral (SEM STORAGE - verdadeiramente efémero)
    ├── Partição 0: Metadados (presence, typing)
    └── Partição 1: Media (chunks P2P de ficheiros grandes)
```

### Benefícios
1. **Privacidade Real**: Metadados de presença nunca são guardados
2. **Estrutura Correta**: Separação clara entre dados persistentes e efémeros
3. **Custo**: Redução de storage (só armazenamos o necessário)
4. **Flexibilidade**: Cada stream pode ter permissões gémeas sincronizadas

### Naming Convention e Derivação de IDs

**Formato Simplificado (sem nome no ID):**
```
Message Stream:    0xOwner/a1b2c3d4-1
Ephemeral Stream:  0xOwner/a1b2c3d4-2
```

- `a1b2c3d4` = hash aleatório (8 chars hex)
- `-1` = stream de mensagens (com storage)
- `-2` = stream efémero (sem storage)

**Derivação (simplifica convites):**
```javascript
// A partir do messageStreamId, derivar o ephemeralStreamId
function deriveEphemeralId(messageStreamId) {
    return messageStreamId.replace(/-1$/, '-2');
}

// A partir do ephemeralStreamId, derivar o messageStreamId
function deriveMessageId(ephemeralStreamId) {
    return ephemeralStreamId.replace(/-2$/, '-1');
}

// Convite só precisa de conter o messageStreamId
// pombo.chat/join?s=0xOwner/a1b2c3d4-1
// O ephemeralStreamId é derivado automaticamente
```

**Benefícios:**
- IDs mais curtos e limpos
- Sem informação exposta no ID (privacidade)
- Nome do canal só nos metadados (e localmente para canais pessoais)

---

## 🏷️ Metadados dos Streams

### Estrutura de Metadados (campo `description` do stream)

Os metadados do stream definem as propriedades do canal e a sua visibilidade.

#### Canal Comunitário (Visível no Explorer)

```json
{
    "app": "pombo",
    "version": "1",
    "name": "BTC Market",
    "type": "public",
    "exposure": "visible",
    "description": "Bitcoin price discussion and market analysis",
    "language": "en",
    "category": "markets",
    "createdAt": 1739836800000
}
```

#### Canal Pessoal (Escondido do Explorer)

```json
{
    "app": "pombo",
    "version": "1",
    "name": null,
    "type": "native",
    "exposure": "hidden",
    "description": null,
    "language": null,
    "category": null,
    "createdAt": 1739836800000
}
```

**Nota:** Para canais pessoais (`exposure: "hidden"`), o nome é guardado **apenas localmente** no `secureStorage`. Isto garante que o nome não é exposto on-chain.

### Campos de Metadados

| Campo | Tipo | Obrigatório | Descrição |
|-------|------|-------------|----------|
| `app` | string | ✅ | Sempre "pombo" |
| `version` | string | ✅ | Versão do schema ("1") |
| `name` | string\|null | ✅ | Nome do canal (null para hidden) |
| `type` | string | ✅ | "public", "private", "native" |
| `exposure` | string | ✅ | "visible" ou "hidden" |
| `description` | string\|null | ❌ | Descrição do canal |
| `language` | string\|null | ❌ | Código ISO 639-1 ("en", "pt", etc.) |
| `category` | string\|null | ❌ | Categoria do canal |
| `createdAt` | number | ✅ | Timestamp de criação |

### Categorias Sugeridas

```javascript
const CHANNEL_CATEGORIES = [
    'general',      // Discussão geral
    'markets',      // Mercados financeiros/crypto
    'tech',         // Tecnologia
    'gaming',       // Jogos
    'art',          // Arte/NFTs
    'music',        // Música
    'sports',       // Desporto
    'news',         // Notícias
    'education',    // Educação
    'other'         // Outros
];
```

### Lógica de Visibilidade

```javascript
// Ao criar canal
async createChannel(name, type, options = {}) {
    const isHidden = options.exposure === 'hidden' || type === 'native';
    
    // Gerar IDs
    const hash = cryptoManager.generateRandomHex(8);
    const messageStreamId = `${this.address}/${hash}-1`;
    const ephemeralStreamId = `${this.address}/${hash}-2`;
    
    // Metadados para o stream (on-chain)
    const metadata = {
        app: 'pombo',
        version: '1',
        name: isHidden ? null : name,  // Só expor nome se visible
        type: type,
        exposure: isHidden ? 'hidden' : 'visible',
        description: isHidden ? null : options.description,
        language: isHidden ? null : options.language,
        category: isHidden ? null : options.category,
        createdAt: Date.now()
    };
    
    // Para canais hidden, guardar nome localmente
    const localChannelData = {
        messageStreamId,
        ephemeralStreamId,
        name: name,  // Sempre guardar nome localmente
        type,
        // ...
    };
    
    // ...
}
```

### Pesquisa no Explorer (The Graph)

Canais com `exposure: "visible"` aparecem no explorer público:

```graphql
query SearchPublicChannels($search: String, $category: String, $language: String) {
    streams(where: {
        metadata_contains: "\"app\":\"pombo\"",
        metadata_contains: "\"exposure\":\"visible\""
    }) {
        id
        metadata
        createdAt
    }
}
```

---

## 📋 Análise de Impacto por Módulo

### 1. `streamr.js` - Controlador Streamr
**Impacto: ALTO** 🔴

#### Alterações Necessárias:

```javascript
// ANTES: LOGSTORE_CONFIG com 3 partições num stream
const LOGSTORE_CONFIG = {
    PARTITIONS: {
        MESSAGES: 0,
        CONTROL: 1,
        MEDIA: 2
    }
};

// DEPOIS: Configuração para 2 streams
const STREAM_CONFIG = {
    // Stream de mensagens (COM storage)
    MESSAGE_STREAM: {
        PARTITIONS: 1,
        STORED: true
    },
    // Stream efémero (SEM storage)
    EPHEMERAL_STREAM: {
        PARTITIONS: {
            CONTROL: 0,  // Presence, typing
            MEDIA: 1     // File chunks
        },
        STORED: false
    },
    INITIAL_MESSAGES: 30,
    LOAD_MORE_COUNT: 30
};
```

#### Funções a Modificar:

| Função | Alteração |
|--------|-----------|
| `createStream()` | Criar 2 streams em vez de 1 |
| `subscribe()` | Subscrever a ambos os streams |
| `unsubscribe()` | Cancelar subscrição de ambos |
| `publish()` | Rotear para stream correto |
| `publishMessage()` | Publicar no message stream |
| `publishControl()` | Publicar no ephemeral stream (partition 0) |
| `publishMedia()` | Publicar no ephemeral stream (partition 1) |
| `publishReaction()` | Publicar no message stream |
| `enableStorage()` | Aplicar APENAS ao message stream |
| `fetchHistory()` | Buscar APENAS do message stream |
| `subscribeWithHistory()` | Aplicar lógica diferenciada |
| `subscribeWithHistoryAll()` | Subscrever a ambos streams com regras diferentes |

#### Nova Estrutura de Retorno `createStream()`:

```javascript
// ANTES
return {
    streamId: stream.id,
    type: type,
    name: channelName
};

// DEPOIS
return {
    messageStreamId: messageStream.id,    // Stream com storage
    ephemeralStreamId: ephemeralStream.id, // Stream sem storage
    type: type,
    name: channelName
};
```

---

### 2. `channels.js` - Gestor de Canais
**Impacto: ALTO** 🔴

#### Estrutura do Canal - ANTES:

```javascript
const channel = {
    streamId: 'owner/channel-name_hash',
    name: 'channel-name',
    type: 'public',
    // ...
};
```

#### Estrutura do Canal - DEPOIS:

```javascript
const channel = {
    // IDs dos dois streams (gémeos)
    messageStreamId: '0xOwner/a1b2c3d4-1',
    ephemeralStreamId: '0xOwner/a1b2c3d4-2',
    
    // Dados do canal (guardados localmente)
    name: 'My Channel',           // SEMPRE presente localmente
    type: 'public',               // "public", "private", "native"
    exposure: 'visible',          // "visible" ou "hidden"
    
    // Metadados adicionais (apenas para visible)
    description: 'Channel description',
    language: 'en',
    category: 'general',
    
    // Sistema
    createdAt: 1739836800000,
    createdBy: '0xOwner...',
    members: [],
    storageEnabled: true,
    
    // Runtime (não persistido)
    messages: [],
    reactions: {},
    historyLoaded: false,
    hasMoreHistory: true
};
```

#### Funções a Modificar:

| Função | Alteração |
|--------|-----------|
| `createChannel()` | Criar 2 streams, construir metadados com exposure |
| `joinChannel()` | Juntar a ambos streams, extrair nome dos metadados |
| `subscribeToChannel()` | Subscrever a ambos streams |
| `sendMessage()` | Publicar no messageStreamId (via streamr) |
| `publishPresence()` | Publicar no ephemeralStreamId (via streamr) |
| `sendTypingIndicator()` | Publicar no ephemeralStreamId |
| `sendReaction()` | Publicar no messageStreamId |
| `loadMoreHistory()` | Buscar do messageStreamId |
| `addMember()` | Adicionar permissões a AMBOS streams |
| `removeMember()` | Remover permissões de AMBOS streams |
| `isChannelOwner()` | Verificar ownership do messageStreamId |
| `leaveChannel()` | Cancelar subscrição de ambos |
| `saveChannels()` | Guardar ambos IDs |
| `loadChannels()` | Carregar ambos IDs |

---

### 3. `media.js` - Controlador de Media
**Impacto: MÉDIO** 🟡

#### Alterações Necessárias:

```javascript
// ANTES: Usa streamId e partition 2
await streamrController.publishMedia(streamId, mediaData, password);

// DEPOIS: Usa ephemeralStreamId e partition 1
await streamrController.publish(
    channel.ephemeralStreamId, 
    1, // partition 1 = media no stream efémero
    mediaData, 
    password
);
```

#### Funções a Modificar:

| Função | Alteração |
|--------|-----------|
| `sendImage()` | Usar messageStreamId (imagens são persistidas) |
| `sendVideo()` | Announcement no messageStreamId, chunks no ephemeralStreamId |
| `requestImage()` | Pedir do ephemeralStreamId |
| `handleImageRequest()` | Responder no ephemeralStreamId |
| `sendPiece()` | Enviar no ephemeralStreamId |
| `requestFileSources()` | Pedir via ephemeralStreamId |
| `announceFileSource()` | Anunciar no ephemeralStreamId |

#### Decisão de Design: Imagens
**Pergunta**: Imagens devem ser persistidas (messageStream) ou efémeras (ephemeralStream)?

**Recomendação**: 
- **Image announcements** (metadata: imageId, sender, timestamp) → messageStream (persistido)
- **Image data** (base64 payload) → ephemeralStream (efémero, re-solicitável)

Isto mantém o histórico de "quem enviou que imagem quando" mas não armazena os bytes no storage node.

---

### 4. `subscriptionManager.js` - Gestor de Subscrições
**Impacto: MÉDIO** 🟡

#### Análise do Código Atual

O `subscriptionManager.js` atual gere subscrições com as seguintes características:

```javascript
// Estado atual
class SubscriptionManager {
    activeChannelId = null;              // Single stream ID
    activeSubscriptionHandlers = null;
    channelActivity = new Map();         // streamId -> activity data
    // ...
}
```

**Funções principais a modificar**:

| Função Atual | Usa streamId como | Alteração Necessária |
|--------------|-------------------|----------------------|
| `setActiveChannel(streamId, ...)` | Identificador único | Mudar para objeto `channel` |
| `downgradeToBackground(streamId)` | Single unsubscribe | Unsubscribe de 2 streams |
| `checkChannelActivity(channel)` | `streamId` param | Usar `messageStreamId` |
| `forcePollChannel(streamId)` | Query param | Usar `messageStreamId` |
| `getChannelActivity(streamId)` | Map key | Usar `messageStreamId` como key |
| `clearUnreadCount(streamId)` | Map key | Usar `messageStreamId` como key |
| `removeChannel(streamId)` | Identificador | Usar `messageStreamId` |

#### Código Atualizado Detalhado

```javascript
class SubscriptionManager {
    constructor() {
        // MUDANÇA: activeChannel é agora um objeto, não string
        this.activeChannel = null;  // { messageStreamId, ephemeralStreamId, ... }
        this.activeSubscriptionHandlers = null;
        
        // MUDANÇA: Map keyed by messageStreamId (identificador principal)
        this.channelActivity = new Map(); // messageStreamId -> activity
        
        // ... resto igual
    }

    /**
     * ANTES: setActiveChannel(streamId, password, handlers)
     * DEPOIS: Aceita objeto channel com ambos os IDs
     */
    async setActiveChannel(channel, password = null, handlers = null) {
        if (!channel?.messageStreamId) {
            Logger.warn('setActiveChannel called with invalid channel');
            return;
        }

        // Se mesmo canal, ignorar
        if (this.activeChannel?.messageStreamId === channel.messageStreamId) {
            Logger.debug('Channel already active:', channel.messageStreamId);
            return;
        }

        Logger.info('Setting active channel:', channel.messageStreamId);

        // Downgrade anterior (ambos streams)
        if (this.activeChannel) {
            await this.downgradeToBackground(this.activeChannel);
        }

        this.activeChannel = channel;
        this.activeSubscriptionHandlers = handlers;

        try {
            // 1. Subscrever messageStream COM history
            await streamrController.subscribeWithHistory(
                channel.messageStreamId,
                0, // partition 0 = messages
                handlers?.onMessage,
                STREAM_CONFIG.INITIAL_MESSAGES,
                password
            );

            // 2. Subscrever ephemeralStream SEM history (não existe)
            await streamrController.subscribe(
                channel.ephemeralStreamId,
                0, // partition 0 = control/presence
                handlers?.onControl,
                password
            );
            
            // 3. Subscrever partition 1 do ephemeral (media)
            await streamrController.subscribe(
                channel.ephemeralStreamId,
                1, // partition 1 = media
                handlers?.onMedia,
                password
            );

            Logger.info('Active channel subscriptions complete');
        } catch (error) {
            Logger.error('Failed to subscribe to active channel:', error);
            // Cleanup em caso de erro parcial
            await this.downgradeToBackground(channel);
            throw error;
        }
    }

    /**
     * ANTES: downgradeToBackground(streamId)
     * DEPOIS: Cancela subscrição de AMBOS streams
     */
    async downgradeToBackground(channel) {
        if (!channel?.messageStreamId) return;

        try {
            // Store activity state
            const activity = this.channelActivity.get(channel.messageStreamId);
            if (activity) {
                activity.lastChecked = Date.now();
            }

            // Unsubscribe de AMBOS streams
            await Promise.allSettled([
                streamrController.unsubscribe(channel.messageStreamId),
                streamrController.unsubscribe(channel.ephemeralStreamId)
            ]);
            
            Logger.debug('Downgraded to background:', channel.messageStreamId);
        } catch (error) {
            Logger.warn('Failed to downgrade channel:', error.message);
        }
    }

    /**
     * Activity check - APENAS messageStream (ephemeral não tem history)
     */
    async checkChannelActivity(channel) {
        const messageStreamId = channel.messageStreamId;
        const password = channel.password || null;

        const currentActivity = this.channelActivity.get(messageStreamId) || {
            lastMessageTime: 0,
            unreadCount: 0,
            lastChecked: 0
        };

        try {
            // APENAS query ao messageStream (o único com storage)
            const result = await streamrController.fetchOlderHistory(
                messageStreamId,
                0, // Messages partition
                Date.now(),
                this.config.ACTIVITY_CHECK_MESSAGES,
                password
            );

            // ... resto da lógica igual, mas keyed por messageStreamId
        } catch (error) {
            // ...
        }
    }

    /**
     * Helper: Check if channel is active
     */
    isActiveChannel(channel) {
        if (typeof channel === 'string') {
            // Backward compat: aceitar messageStreamId como string
            return this.activeChannel?.messageStreamId === channel;
        }
        return this.activeChannel?.messageStreamId === channel?.messageStreamId;
    }

    /**
     * Get active channel ID (para UI)
     */
    getActiveChannelId() {
        return this.activeChannel?.messageStreamId || null;
    }
}
```

#### Performance: Impacto de Duas Subscrições

**Análise do código atual**:
- `config.MAX_CONCURRENT_SUBS: 1` - Apenas 1 canal ativo
- Background channels são polled, não subscribed
- Poll usa `fetchOlderHistory()` - apenas messageStream precisa

**Impacto**:
| Métrica | Antes | Depois |
|---------|-------|--------|
| WebSocket connections (active) | 1 stream × 3 partitions | 2 streams × (1 + 2 partitions) |
| Background poll queries | 1 per channel | 1 per channel (só message) |
| Memory per active channel | ~moderate | ~2x por subscrição adicional |

**Otimização sugerida**: Subscrição lazy do ephemeral

```javascript
// Só subscrever ephemeral quando UI de presença está visível
async enablePresenceUI(channel) {
    if (!this.ephemeralSubscribed.has(channel.ephemeralStreamId)) {
        await streamrController.subscribe(channel.ephemeralStreamId, 0, ...);
        this.ephemeralSubscribed.add(channel.ephemeralStreamId);
    }
}
```

**DECISÃO**: Manter subscrição eager por simplicidade (v0). Otimizar se performance for problema.

---

### 5. `secureStorage.js` - Armazenamento Seguro
**Impacto: BAIXO** 🟢

#### Alterações no Schema de Dados:

```javascript
// Schema de canal v0 (dual-stream com visibilidade)
{
    messageStreamId: string,   // Stream com storage (histórico)
    ephemeralStreamId: string, // Stream sem storage (efémero)
    name: string,              // SEMPRE presente localmente (mesmo para hidden)
    type: string,              // "public", "private", "native"
    exposure: string,          // "visible" ou "hidden"
    description: string|null,  // Descrição (se visible)
    language: string|null,     // Idioma (se visible)
    category: string|null,     // Categoria (se visible)
    createdAt: number,
    createdBy: string,
    members: string[],
    storageEnabled: boolean
}
```

**Nota:** Para canais `hidden`, o nome é guardado APENAS aqui. On-chain, o campo `name` nos metadados é `null`.

---

### 6. `graph.js` - API do The Graph
**Impacto: MÉDIO** 🟡

#### Alterações Necessárias:

```javascript
// Pesquisar apenas canais visíveis
async searchPublicChannels(filters = {}) {
    // Filtrar por exposure: "visible"
    // Opcionalmente filtrar por category, language
}
```

#### Funções a Modificar:

| Função | Alteração |
|--------|-----------|
| `getStream()` | Pode precisar de aceitar objeto canal |
| `detectStreamType()` | Verificar messageStreamId |
| `getStreamMembers()` | Retornar membros do messageStreamId |
| `searchPublicPomboStreams()` | **Filtrar por `exposure: "visible"`** |

---

### 7. `ui.js` - Interface do Utilizador
**Impacto: MÉDIO** 🟡

#### Modal de Criação de Canal (Atualizado)

```
┌─────────────────────────────────────────┐
│  Create New Channel                      │
├─────────────────────────────────────────┤
│                                         │
│  Channel Name: [________________]       │
│                                         │
│  Type:                                  │
│  ○ Public (anyone can join)             │
│  ○ Password Protected (private)       │
│  ○ Private (invite only)                │
│                                         │
│  ─────────────────────────────────────  │
│                                         │
│  Visibility:                            │
│  ○ Hidden (personal, not in explorer)   │
│  ○ Visible (community, searchable)      │
│                                         │
│  ┌─ If Visible ──────────────────────┐  │
│  │ Description: [________________]   │  │
│  │ Language:    [English ▼]          │  │
│  │ Category:    [General ▼]          │  │
│  └───────────────────────────────────┘  │
│                                         │
│          [Cancel]    [Create]           │
└─────────────────────────────────────────┘
```

**Lógica:**
- Se `visibility = hidden`: campos de descrição/idioma/categoria ficam ocultos
- Se `type = native` (private): visibilidade forçada para `hidden`

#### Alterações Necessárias:

O UI precisa de exibir/copiar o identificador do canal corretamente.

O UI usa o messageStreamId como identificador único do canal.

```javascript
// Copiar ID do canal (usa messageStreamId)
await navigator.clipboard.writeText(currentChannel.messageStreamId);
```

#### Formato de Convite (Simplificado):

```javascript
// Convite usa apenas messageStreamId - ephemeral é derivado
// pombo.chat/join?s=0xOwner/a1b2c3d4-1&...
const inviteUrl = `${origin}/join?s=${encodeURIComponent(messageStreamId)}`;

// Ao receber convite:
const messageStreamId = urlParams.get('s');
const ephemeralStreamId = messageStreamId.replace(/-1$/, '-2');
```

#### Funções a Modificar:

| Função | Alteração |
|--------|-----------|
| `generateInviteLink()` | Usar apenas messageStreamId |
| `handleJoinFromInvite()` | Derivar ephemeralStreamId |
| `showChannelDropdown()` | Mostrar info atualizada |
| `updateOnlineUsers()` | Usar dados do ephemeralStream |

---

### 8. `app.js` - Ponto de Entrada
**Impacto: BAIXO** 🟢

#### Alterações Necessárias:

```javascript
// Convite simplificado - apenas messageStreamId
const messageStreamId = urlParams.get('s');
const ephemeralStreamId = messageStreamId.replace(/-1$/, '-2');
```

---

## ⚠️ NOTA: Versão 0 - Sem Código Legacy

**Esta é uma implementação v0.** Não há utilizadores existentes nem canais para migrar. Isto significa:

- ✅ Implementação limpa desde o início
- ✅ Sem necessidade de compatibilidade backward
- ✅ Sem migração de dados
- ✅ Formato de convites pode ser otimizado
- ❌ Canais criados antes desta atualização serão perdidos (aceitável em v0)

---

## 📊 Tabela de Decisões de Design

| Aspeto | Decisão | Justificação |
|--------|---------|--------------|
| **Naming** | `hash-1` e `hash-2` sufixos | IDs limpos, sem expor nome |
| **Partições ephemeral** | 2 (control=0, media=1) | Separação lógica |
| **Imagem metadata** | messageStream | Histórico de "quem enviou quando" |
| **Imagem data** | ephemeralStream | Não persistir bytes |
| **Reactions** | messageStream | Persistir com mensagens |
| **Video announce** | messageStream | Histórico de ficheiros partilhados |
| **Video chunks** | ephemeralStream | P2P efémero |
| **Convites** | Derivar ephemeralId do messageId | URL mais curto |
| **Permissões** | **GÉMEAS** - sempre sincronizadas | Segurança crítica |
| **Legacy** | Nenhum - v0 clean slate | Sem utilizadores existentes |
| **Visibilidade** | `visible`/`hidden` nos metadados | Privacidade no explorer |
| **Nome em hidden** | null on-chain, local no storage | Não expor nomes pessoais |

---

## 📝 Checklist de Implementação

### Fase 1: Preparação
- [ ] Criar branch `feature/dual-stream-architecture`
- [ ] Limpar dados de teste existentes (v0 - clean slate)

### Fase 2: Core (streamr.js)
- [ ] Atualizar `LOGSTORE_CONFIG` → `STREAM_CONFIG`
- [ ] Modificar `createStream()` para criar 2 streams com IDs `hash-1` e `hash-2`
- [ ] **Implementar construção de metadados com exposure/description/language/category**
- [ ] Atualizar `subscribe()` e `unsubscribe()`
- [ ] Atualizar métodos de publish
- [ ] Modificar `enableStorage()` para aplicar só ao messageStream
- [ ] Atualizar `fetchHistory()` e métodos relacionados

### Fase 3: Canais (channels.js)
- [ ] Atualizar estrutura do objeto channel (novos campos)
- [ ] Modificar `createChannel()` para aceitar exposure e metadados
- [ ] **Implementar lógica: hidden → nome null on-chain**
- [ ] Modificar `joinChannel()` para extrair nome dos metadados
- [ ] Atualizar `subscribeToChannel()`
- [ ] Modificar métodos de presence
- [ ] Atualizar gestão de membros (permissões gémeas)

### Fase 4: Media (media.js)
- [ ] Atualizar routing de mensagens
- [ ] Modificar `sendImage()` e `sendVideo()`
- [ ] Atualizar handlers de chunks

### Fase 5: Subscrições (subscriptionManager.js)
- [ ] Atualizar lógica de canal ativo
- [ ] Modificar background polling

### Fase 6: Storage (secureStorage.js)
- [ ] Atualizar schema de canais (novos campos exposure, description, etc.)
- [ ] Atualizar serialização de canais

### Fase 7: UI (ui.js)
- [ ] Atualizar geração de convites
- [ ] Modificar parsing de convites
- [ ] Atualizar displays de informação
- [ ] **Adicionar UI para seleção visible/hidden**
- [ ] **Adicionar campos: descrição, idioma, categoria (para visible)**
- [ ] **Atualizar modal de criação de canal**

### Fase 8: Graph (graph.js)
- [ ] Atualizar queries para filtrar por `exposure: "visible"`
- [ ] Modificar deteção de tipo
- [ ] **Adicionar pesquisa por categoria/idioma**

### Fase 9: Testes e Cleanup
- [ ] Testar criação de canais novos
- [ ] Testar join de canais novos
- [ ] Testar presença (deve ser efémera)
- [ ] Verificar que typing não aparece no history
- [ ] **Testar sincronização de permissões gémeas**
- [ ] Testar adição/remoção de membros em ambos streams

---

## 🔐 GESTÃO DE PERMISSÕES GÉMEAS (CRÍTICO)

### Princípio Fundamental

**Os dois streams de um canal DEVEM ter permissões idênticas em todos os momentos.**

Se um utilizador tem acesso ao `messageStream`, DEVE ter acesso ao `ephemeralStream` e vice-versa.
Qualquer dessincronização é uma **falha de segurança**.

### Operações Atómicas

Todas as operações de permissão devem ser tratadas atomicamente:

```javascript
/**
 * Gestor de Permissões Gémeas
 * Garante que ambos os streams têm permissões sincronizadas
 */
class TwinPermissionManager {
    /**
     * Concede permissões a um utilizador em AMBOS os streams
     * @param {string} messageStreamId - ID do stream de mensagens
     * @param {string} ephemeralStreamId - ID do stream efémero
     * @param {string} userAddress - Endereço do utilizador
     * @param {string[]} permissions - Permissões a conceder
     */
    async grantToUser(messageStreamId, ephemeralStreamId, userAddress, permissions = ['subscribe', 'publish']) {
        const normalizedAddress = userAddress.toLowerCase();
        
        // Fase 1: Conceder ao messageStream
        let messageSuccess = false;
        try {
            await this.client.setPermissions({
                streamId: messageStreamId,
                assignments: [{ userId: normalizedAddress, permissions }]
            });
            messageSuccess = true;
            Logger.debug('Permissões concedidas ao messageStream');
        } catch (error) {
            Logger.error('Falha ao conceder permissões ao messageStream:', error);
            throw new Error(`Falha ao conceder permissões: ${error.message}`);
        }
        
        // Fase 2: Conceder ao ephemeralStream
        try {
            await this.client.setPermissions({
                streamId: ephemeralStreamId,
                assignments: [{ userId: normalizedAddress, permissions }]
            });
            Logger.debug('Permissões concedidas ao ephemeralStream');
        } catch (error) {
            // ROLLBACK: Se falhar no ephemeral, revogar do message
            Logger.error('Falha ao conceder permissões ao ephemeralStream, executando rollback...');
            if (messageSuccess) {
                try {
                    await this.client.setPermissions({
                        streamId: messageStreamId,
                        assignments: [{ userId: normalizedAddress, permissions: [] }]
                    });
                    Logger.debug('Rollback executado com sucesso');
                } catch (rollbackError) {
                    Logger.error('FALHA CRÍTICA: Rollback falhou, streams dessincronizados!', rollbackError);
                    // TODO: Marcar canal para reparação
                }
            }
            throw new Error(`Falha ao sincronizar permissões: ${error.message}`);
        }
    }
    
    /**
     * Revoga permissões de um utilizador em AMBOS os streams
     */
    async revokeFromUser(messageStreamId, ephemeralStreamId, userAddress) {
        const normalizedAddress = userAddress.toLowerCase();
        const errors = [];
        
        // Tentar revogar de ambos (best effort para remoção)
        try {
            await this.client.setPermissions({
                streamId: messageStreamId,
                assignments: [{ userId: normalizedAddress, permissions: [] }]
            });
        } catch (e) {
            errors.push(`messageStream: ${e.message}`);
        }
        
        try {
            await this.client.setPermissions({
                streamId: ephemeralStreamId,
                assignments: [{ userId: normalizedAddress, permissions: [] }]
            });
        } catch (e) {
            errors.push(`ephemeralStream: ${e.message}`);
        }
        
        if (errors.length > 0) {
            Logger.warn('Erros ao revogar permissões:', errors);
        }
    }
    
    /**
     * Concede permissões públicas a AMBOS os streams
     */
    async grantPublicAccess(messageStreamId, ephemeralStreamId) {
        // Mesmo padrão: messageStream primeiro, ephemeral segundo, rollback se necessário
        let messageSuccess = false;
        
        try {
            await this.client.setPermissions({
                streamId: messageStreamId,
                assignments: [{ public: true, permissions: ['subscribe', 'publish'] }]
            });
            messageSuccess = true;
        } catch (error) {
            throw new Error(`Falha ao configurar permissões públicas: ${error.message}`);
        }
        
        try {
            await this.client.setPermissions({
                streamId: ephemeralStreamId,
                assignments: [{ public: true, permissions: ['subscribe', 'publish'] }]
            });
        } catch (error) {
            // Rollback
            if (messageSuccess) {
                await this.client.setPermissions({
                    streamId: messageStreamId,
                    assignments: [{ public: true, permissions: [] }]
                }).catch(() => {});
            }
            throw new Error(`Falha ao sincronizar permissões públicas: ${error.message}`);
        }
    }
    
    /**
     * Verifica se ambos os streams têm permissões sincronizadas
     * @returns {Promise<{synced: boolean, differences: Array}>}
     */
    async verifySync(messageStreamId, ephemeralStreamId) {
        const msgPerms = await this.getPermissions(messageStreamId);
        const ephPerms = await this.getPermissions(ephemeralStreamId);
        
        // Comparar permissões
        const differences = [];
        const msgUsers = new Set(msgPerms.map(p => p.userId || 'public'));
        const ephUsers = new Set(ephPerms.map(p => p.userId || 'public'));
        
        // Utilizadores em message mas não em ephemeral
        for (const user of msgUsers) {
            if (!ephUsers.has(user)) {
                differences.push({ user, issue: 'missing_in_ephemeral' });
            }
        }
        
        // Utilizadores em ephemeral mas não em message
        for (const user of ephUsers) {
            if (!msgUsers.has(user)) {
                differences.push({ user, issue: 'missing_in_message' });
            }
        }
        
        return {
            synced: differences.length === 0,
            differences
        };
    }
}
```

### Regras de Negócio

1. **Criação de Canal**
   - Criar messageStream
   - Criar ephemeralStream
   - Configurar permissões em AMBOS atomicamente
   - Se falhar em qualquer um, eliminar AMBOS

2. **Adição de Membro**
   - `grantToUser()` com rollback automático
   - Nunca adicionar a apenas um stream

3. **Remoção de Membro**
   - `revokeFromUser()` best-effort em ambos
   - Aceitar remoção parcial (segurança > consistência perfeita)

4. **Canais Públicos/Private**
   - `grantPublicAccess()` a ambos
   - Mesmas permissões públicas

5. **Verificação Periódica**
   - Ao abrir settings do canal, verificar sync
   - Alertar se dessincronizado
   - Opção de "reparar" permissões

### Casos Especiais

| Cenário | Ação |
|---------|------|
| Falha ao criar ephemeralStream | Eliminar messageStream criado |
| Falha ao dar permissão a ephemeral | Rollback permissão no message |
| User tem acesso a message mas não ephemeral | Canal "corrompido" - oferecer reparação |
| Owner perde acesso a um stream | Situação crítica - alertar |

---

## ⚠️ Riscos e Mitigação

| Risco | Probabilidade | Impacto | Mitigação |
|-------|--------------|---------|-----------|
| Permissões dessincronizadas | Média | **CRÍTICO** | Operações atómicas, rollback |
| Falha de permissões em 1 dos streams | Média | Alto | Verificação dupla, retry logic |
| UI mostra streamId errado | Baixa | Baixo | Testes de UI |
| Custos de gas duplicados | Alta | Médio | Batch transactions, informar user |

---

## 💰 Impacto nos Custos de Gas

### Criação de Canal
- **Antes**: 1 stream (420k gas) + 1 storage assignment (165k gas) = ~585k gas
- **Depois**: 2 streams (840k gas) + 1 storage assignment (165k gas) = ~1005k gas
- **Aumento**: ~72% mais gas na criação

### Adição de Membro
- **Antes**: 1 permission set (~80k gas)
- **Depois**: 2 permission sets (~160k gas)
- **Aumento**: ~100% mais gas por membro

**Nota**: O custo aumentado de gas é o preço da privacidade correta. Pode-se otimizar usando batch transactions onde possível.

---

## � ANÁLISE CRÍTICA - Problemas Identificados

### 1. Derivação de IDs - Regex Frágil ⚠️

**Problema**: O padrão `/-1$/` e `/-2$/` pode falhar se o hash aleatório terminar em `-1` ou `-2`.

```javascript
// Exemplo problemático:
// hash gerado: "abc-1"
// messageStreamId: "0xOwner/abc-1-1"
// derivação: "0xOwner/abc-1-1".replace(/-1$/, '-2') = "0xOwner/abc-1-2" ✓
// MAS se hash for "abc1":
// messageStreamId: "0xOwner/abc1-1"
// "0xOwner/abc1-1".replace(/-1$/, '-2') = "0xOwner/abc1-2" ✓ (OK)

// Problema real: colisão visual
// hash "a-1": "0xOwner/a-1-1" parece estranho
```

**Solução**: Garantir que o hash NUNCA contém hífens:
```javascript
const hash = cryptoManager.generateRandomHex(8); // hex = 0-9, a-f, sem hífens
```

**NOTA**: Se `generateRandomHex` usa apenas caracteres hexadecimais (0-9, a-f), não há problema.

---

### 2. Join de Canais Hidden - Nome Desconhecido ✅ RESOLVIDO

**Problema**: Para canais `hidden`, o nome é `null` on-chain. Quem faz join via convite não sabe o nome.

**DECISÃO**: ✅ Convite inclui nome **encriptado**

```javascript
// Formato do convite para canais hidden
// O nome é encriptado com a password do canal (se existir) ou chave derivada
const inviteUrl = `${origin}/join?s=${messageStreamId}&n=${encryptedName}`;

// Ao processar convite:
async function handleInvite(params) {
    const messageStreamId = params.s;
    const encryptedName = params.n; // pode ser null para canais visible
    
    if (encryptedName) {
        // Desencriptar nome com password do canal
        const channelName = await decryptChannelName(encryptedName, password);
        channel.name = channelName;
    } else {
        // Canal visible - buscar nome dos metadados on-chain
        const metadata = await getStreamMetadata(messageStreamId);
        channel.name = metadata.name;
    }
}
```

**Implementação**:
- Para canais `hidden` com password: encriptar nome com a password
- Para canais `hidden` sem password (native): encriptar com chave do owner (partilhada via convite)
- Para canais `visible`: nome vem dos metadados on-chain (n= omitido no URL)

---

### 3. Metadados do Ephemeral Stream ✅ RESOLVIDO

**DECISÃO**: ✅ Aceite a recomendação

```javascript
// messageStream metadata (completo)
const messageMetadata = JSON.stringify({
    a: 'pombo',      // app (abreviado)
    v: '1',          // version
    n: channelName,  // name (null se hidden)
    t: 'public',     // type: public|private|native
    e: 'visible',    // exposure: visible|hidden  
    d: description,  // description (opcional)
    l: 'pt',         // language (opcional)
    c: 'tech',       // category (opcional)
    ts: Date.now()   // createdAt
});

// ephemeralStream metadata (mínimo)
const ephemeralMetadata = JSON.stringify({
    a: 'pombo',
    v: '1',
    ln: messageStreamId  // linkedTo (abreviado)
});
```

**Nota**: Chaves abreviadas para reduzir tamanho de metadados. Ver secção 8.

---

### 4. GraphQL Query - Edge Cases ✅ RISCO ACEITE

**Problema**: A query usa `metadata_contains` com strings JSON.

**DECISÃO**: ✅ Aceitar o risco mínimo (v0)

```graphql
# Query usa chaves abreviadas, reduzindo risco de colisão
metadata_contains: "\"e\":\"visible\""
```

**Mitigação**: Sanitização de campos de descrição para remover aspas duplas.

---

### 5. Delete/Criação de Canal - Atomicidade ⚠️ LIMITAÇÃO CONHECIDA

**Problema**: Operações em 2 streams não são atómicas. Possíveis estados inconsistentes:
- Criar messageStream OK, criar ephemeralStream FAIL → stream órfão
- Eliminar messageStream OK, eliminar ephemeralStream FAIL → stream órfão

**DECISÃO**: ⚠️ **Não há garantia atómica verdadeira** - Streamr não suporta transações multi-stream.

**Estratégia: Best-Effort com Retry**

```javascript
// CRIAÇÃO - Rollback em caso de falha
async createChannel(...) {
    let messageStream = null;
    let ephemeralStream = null;
    
    try {
        // 1. Criar messageStream
        messageStream = await createMessageStream(...);
        
        // 2. Criar ephemeralStream  
        ephemeralStream = await createEphemeralStream(...);
        
        // 3-4. Permissões e storage...
        return { messageStream, ephemeralStream };
        
    } catch (error) {
        // CLEANUP com retry
        await this.cleanupOrphanStreams(messageStream, ephemeralStream);
        throw error;
    }
}

async cleanupOrphanStreams(msg, eph, maxRetries = 3) {
    for (let attempt = 0; attempt < maxRetries; attempt++) {
        const errors = [];
        
        if (msg) {
            try {
                await this.client.deleteStream(msg.id);
                msg = null; // Success
            } catch (e) {
                errors.push(`msg: ${e.message}`);
            }
        }
        
        if (eph) {
            try {
                await this.client.deleteStream(eph.id);
                eph = null; // Success
            } catch (e) {
                errors.push(`eph: ${e.message}`);
            }
        }
        
        if (!msg && !eph) return; // Both cleaned
        
        // Wait before retry
        await new Promise(r => setTimeout(r, 2000 * (attempt + 1)));
    }
    
    // Se ainda há órfãos após retries
    Logger.error('ORPHAN STREAMS - cleanup failed after retries');
    // TODO: Registar para limpeza posterior
}

// DELETE - Best effort, sem rollback
async deleteChannel(channel) {
    const results = await Promise.allSettled([
        streamrController.deleteStream(channel.messageStreamId),
        streamrController.deleteStream(channel.ephemeralStreamId)
    ]);
    
    const errors = results
        .filter(r => r.status === 'rejected')
        .map(r => r.reason.message);
    
    // Remover localmente SEMPRE (stream órfão é inofensivo)
    this.channels.delete(channel.messageStreamId);
    await this.saveChannels();
    
    if (errors.length > 0) {
        Logger.warn('Delete parcial:', errors);
        // Não lançar erro - canal foi removido localmente
    }
}
```

**Nota**: Stream órfão (sem par) é inofensivo:
- Sem exposição de dados privados  
- Não interfere com outros canais
- Pode ser limpo manualmente pelo owner
```

---

### 6. Type Renaming: Password → Private ✅ RESOLVIDO

**DECISÃO**: ✅ Renomear `type: "password"` para `type: "private"`

**Justificação**: 
- "Private" descreve melhor a intenção (acesso restrito)
- "Password" era confuso (parecia que a password era obrigatória)

**Tipos finais**:
| Tipo | Descrição | Permissões Streamr |
|------|-----------|--------------------|
| `public` | Qualquer pessoa pode ler/escrever | Públicas |
| `private` | Acesso com password (encriptação client-side) | Públicas* |
| `native` | Apenas membros convidados | Por membro |

*Private channels têm permissões públicas na rede, mas mensagens encriptadas.

**Combinação `private` + `visible`**: ✅ Válida e útil
- Canal aparece no explorer
- Requer password para ler mensagens  
- Caso de uso: comunidades descobríveis mas fechadas
- UI do explorer já diferencia por type (sem alterações necessárias)

---

### 7. Join com Ephemeral Inexistente ⚠️

**Problema**: Se o user tenta join com um messageStreamId e derivar o ephemeralStreamId, mas este não existe:
- Canal foi criado com versão antiga?
- Stream foi eliminado?
- Bug na criação?

**Solução**: Verificar existência de AMBOS os streams antes de completar join:
```javascript
async joinChannel(messageStreamId, password = null) {
    const ephemeralStreamId = deriveEphemeralId(messageStreamId);
    
    // Verificar que ambos existem
    const [msgStream, ephStream] = await Promise.all([
        this.client.getStream(messageStreamId).catch(() => null),
        this.client.getStream(ephemeralStreamId).catch(() => null)
    ]);
    
    if (!msgStream) {
        throw new Error('Canal não encontrado');
    }
    
    if (!ephStream) {
        throw new Error('Canal incompleto (stream efémero em falta)');
    }
    
    // Continuar join...
}
```

---

### 8. Limite de Tamanho de Metadados ✅ INVESTIGADO

**Investigação**:
- Streamr SDK **não impõe limite explícito** no campo `description`
- O campo é guardado on-chain como string no contrato StreamRegistry
- Limite prático: custo de gas aumenta com tamanho
- Limite teórico: ~24KB (limite de transação Ethereum)

**DECISÃO**: ✅ Usar chaves abreviadas + limites razoáveis

**Schema de metadados abreviado**:
```javascript
// Chaves abreviadas para minimizar tamanho
const METADATA_KEYS = {
    app: 'a',           // "pombo"
    version: 'v',       // "1"
    name: 'n',          // nome do canal
    type: 't',          // public|private|native
    exposure: 'e',      // visible|hidden
    description: 'd',   // descrição
    language: 'l',      // código ISO
    category: 'c',      // categoria
    createdAt: 'ts',    // timestamp
    linkedTo: 'ln'      // para ephemeral stream
};

// Limites
const LIMITS = {
    MAX_NAME_LENGTH: 50,
    MAX_DESCRIPTION_LENGTH: 280,  // Tipo Twitter
    MAX_METADATA_TOTAL: 1024      // ~1KB total
};

// Validação
function validateMetadata(opts) {
    if (opts.name?.length > LIMITS.MAX_NAME_LENGTH) {
        throw new Error(`Nome máx: ${LIMITS.MAX_NAME_LENGTH} chars`);
    }
    if (opts.description?.length > LIMITS.MAX_DESCRIPTION_LENGTH) {
        throw new Error(`Descrição máx: ${LIMITS.MAX_DESCRIPTION_LENGTH} chars`);
    }
}
```

**Exemplo de metadata compacto**:
```json
{"a":"pombo","v":"1","n":"Tech Talk","t":"public","e":"visible","d":"Tech discussions","l":"en","c":"tech","ts":1708185600000}
```
~130 bytes vs ~200 bytes com chaves completas.

---

### 9. Ordem de Criação - Stream Órfão ✅ COBERTO

**Ver Problema #5** - Mesma solução de best-effort com retry aplica-se à criação.

---

### 10. Hash Collision ✅ RESOLVIDO

**Problema original**: Hash de 6 caracteres hex = 16^6 = ~16.7 milhões de combinações.

**DECISÃO**: ✅ Usar **8 caracteres** (16^8 = ~4.3 biliões de combinações)

```javascript
async generateUniqueHash() {
    const hash = cryptoManager.generateRandomHex(8); // 8 chars
    return hash;
}
```

**Justificação**:
- 4.3 biliões de combinações por owner
- Mesmo com 1000 canais/dia, levaria 11.000 anos para 50% de probabilidade de colisão
- Verificação de existência ainda recomendada como segurança extra

```javascript
// Segurança extra (opcional mas recomendado)
async generateUniqueHashSafe() {
    for (let attempt = 0; attempt < 3; attempt++) {
        const hash = cryptoManager.generateRandomHex(8); // 8 chars
        const streamId = `${this.address}/${hash}-1`;
        
        try {
            await this.client.getStream(streamId);
            // Stream existe (improvável), tentar outro
            continue;
        } catch (e) {
            // Stream não existe, hash é único
            return hash;
        }
    }
    throw new Error('Falha ao gerar hash único após 3 tentativas');
}
```

---

### 11. Categoria/Idioma para Canais Visible ✅ DECIDIDO

**DECISÃO**: ✅ Manter opcionais

- Categoria e idioma são opcionais mesmo para canais `visible`
- UI sugere valores mas não obriga
- Default: `category: null`, `language: null`
- Explorer pode ter seção "Sem categoria" para canais não categorizados

---

## 📝 NOTAS ADICIONAIS

### Consistência de Dados

1. **Fonte de verdade**: 
   - On-chain (metadados) = fonte autoritativa para canais visible
   - Local storage = única fonte para canais hidden

2. **Conflito de dados**: Se metadados on-chain diferem do local storage (ex: user editou), qual prevalece?
   - **Sugestão**: On-chain prevalece para campos públicos, local para campos privados

### Encriptação de Canais Private

**Nota importante**: Para canais `private` (antigo "password"), os metadados (incluindo nome, descrição) estão em **plain text** on-chain no campo description do stream. Apenas as MENSAGENS são encriptadas.

**Implicação**: Se um canal password é `visible`, o nome e descrição são públicos mesmo que as mensagens não sejam.

### Performance: Duas Subscrições

**Nota**: Cada canal ativo agora requer 2 subscrições WebSocket em vez de 1.
- Potencial impacto em dispositivos móveis/redes lentas
- Considerar subscrição lazy do ephemeralStream (só quando necessário)

### The Graph - Indexação

**Nota**: The Graph pode demorar alguns minutos a indexar novos streams. 
- Canais recém-criados podem não aparecer imediatamente no explorer
- Considerar mostrar aviso: "O seu canal pode demorar alguns minutos a aparecer no explorer"

### Backup de Nome para Canais Hidden

**Sugestão**: Para canais hidden criados pelo próprio user, fazer backup do nome:
- IndexedDB local (já existe para media)
- Ou incluir nome encriptado nos metadados (encriptar com password do canal se aplicável)

---

## 🔮 Considerações Futuras

1. **Caching de Streams**: Manter referências aos streams para evitar queries repetidas
2. **Batch Transactions**: Investigar se Streamr suporta batch de permissões cross-stream
3. **Health Check**: Ferramenta automática para verificar sincronização de permissões gémeas
4. **Hash mais longo**: Se colisões se tornarem problema, migrar para 8 caracteres
5. **Subscrição Lazy**: Só subscrever ephemeralStream quando UI de presença está visível

---

## 📚 Referências

- [Streamr SDK Documentation](https://docs.streamr.network/)
- [Streamr GitHub - streamr-dev/network](https://github.com/streamr-dev/network)
- [LogStore Documentation](https://docs.logstore.usher.so/)
- [The Graph - Streamr Subgraph](https://thegraph.com/explorer/subgraphs/EGWFdhhiWypDuz22Uy7b3F69E9MEkyfU9iAQMttkH5Rj)

---

*Documento criado: 17 de Fevereiro de 2026*  
*Versão: 0.1 (v0 - Clean Slate)*
